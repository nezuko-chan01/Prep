const clickHereBtn = document.getElementById('clickHereBtn');
const popup = document.getElementById('popup');
const tellMeBtn = document.getElementById('tellMeBtn');
const dontKnowBtn = document.getElementById('dontKnowBtn');
const angryCat = document.getElementById('angryCat');
const goBackBtn = document.getElementById('goBackBtn');
const happyCat = document.getElementById('happyCat');
const homeBtn = document.getElementById('homeBtn');
const tapSection = document.getElementById('tapSection');
const bigNote = document.getElementById('bigNote');

clickHereBtn.addEventListener('click', () => {
  document.querySelector('.home').style.display = 'none';
  popup.style.display = 'block';
});

tellMeBtn.addEventListener('click', () => {
  popup.style.display = 'none';
  happyCat.style.display = 'block';
});

dontKnowBtn.addEventListener('click', () => {
  popup.style.display = 'none';
  angryCat.style.display = 'block';
});

goBackBtn.addEventListener('click', () => {
  angryCat.style.display = 'none';
  document.querySelector('.home').style.display = 'block';
});

homeBtn.addEventListener('click', () => {
  happyCat.style.display = 'none';
  document.querySelector('.home').style.display = 'block';
});

tapSection.addEventListener('click', () => {
  bigNote.style.display = 'block';
});